
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    from_json,
    to_timestamp,
    avg,
    window,
    struct,
    to_json
)
from pyspark.sql.types import (
    StructType,
    StructField,
    IntegerType,
    DoubleType,
    StringType
)

# 1. Створення Spark Session
spark = SparkSession.builder \
    .appName("BuildingSensorAlerts") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

# 2. Схема повідомлень сенсорів
schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("temperature", DoubleType(), True),
    StructField("humidity", DoubleType(), True),
    StructField("timestamp", StringType(), True)
])

# 3. Читання даних із Kafka
kafka_stream = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "building_sensors") \
    .option("startingOffsets", "latest") \
    .load()

# 4. Перетворення JSON
sensors = kafka_stream.select(
    from_json(
        col("value").cast("string"),
        schema
    ).alias("data")
).select("data.*")

# 5. Перетворення timestamp
sensors = sensors.withColumn(
    "event_time",
    to_timestamp(col("timestamp"))
)

# 6. Агрегація Sliding Window
aggregated = sensors \
    .withWatermark("event_time", "10 seconds") \
    .groupBy(
        window(
            col("event_time"),
            "1 minute",
            "30 seconds"
        )
    ) \
    .agg(
        avg("temperature").alias("avg_temperature"),
        avg("humidity").alias("avg_humidity")
    )

# 7. Читання умов алертів із CSV
conditions = spark.read \
    .option("header", True) \
    .option("inferSchema", True) \
    .option("sep", ",") \
    .csv("alerts_conditions.csv")

# 8. Cross Join
combined = aggregated.crossJoin(conditions)

# 9. Фільтрація умов алертів
alerts = combined.filter(
    (
        (col("humidity_min") == -999) |
        (col("avg_humidity") >= col("humidity_min"))
    ) &
    (
        (col("humidity_max") == -999) |
        (col("avg_humidity") <= col("humidity_max"))
    ) &
    (
        (col("temperature_min") == -999) |
        (col("avg_temperature") >= col("temperature_min"))
    ) &
    (
        (col("temperature_max") == -999) |
        (col("avg_temperature") <= col("temperature_max"))
    )
)

# 10. Формування повідомлень JSON
result = alerts.select(
    to_json(
        struct(
            col("window.start").alias("window_start"),
            col("window.end").alias("window_end"),
            col("avg_temperature"),
            col("avg_humidity"),
            col("code"),
            col("message")
        )
    ).alias("value")
)

# 11. Запис алертів у Kafka
query = result.writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("topic", "alerts") \
    .option("checkpointLocation", "spark-checkpoint") \
    .outputMode("append") \
    .start()

print("Sensor alert monitoring started!")

query.awaitTermination()
