
import json
import time
import random
from datetime import datetime, timezone
from kafka import KafkaProducer

producer = KafkaProducer(
    bootstrap_servers="localhost:9092",
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

while True:
    data = {
        "id": random.randint(1, 10),
        "temperature": round(random.uniform(15, 40), 2),
        "humidity": round(random.uniform(20, 90), 2),
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

    producer.send("building_sensors", value=data)
    producer.flush()

    print("Sent:", data)

    time.sleep(2)
